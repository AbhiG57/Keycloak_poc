require('dotenv').config();  // Load .env variables
const express = require('express');
const session = require('express-session');
const axios = require('axios');
const jwt = require('jsonwebtoken');
const cors = require('cors');
 
const app = express();
const PORT = process.env.PORT || 3000;
 
// Keycloak Config
const KEYCLOAK_BASE_URL = process.env.KEYCLOAK_BASE_URL;
const REALM = process.env.REALM;
const CLIENT_ID = process.env.CLIENT_ID;
const CLIENT_SECRET = process.env.CLIENT_SECRET;
const CALLBACK_URL = process.env.CALLBACK_URL;
 
// UI & Backend
const UI_URL = process.env.UI_URL;
const BACKEND_URL = process.env.BACKEND_URL;
 
app.use(express.json());
app.use(cors({ origin: UI_URL, credentials: true }));
 
app.use(session({
    secret: 'supersecret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }  // Set to true if using HTTPS
}));
 
function getKeycloakLoginUrl() {
    return `${KEYCLOAK_BASE_URL}/realms/${REALM}/protocol/openid-connect/auth?client_id=${CLIENT_ID}&response_type=code&redirect_uri=${CALLBACK_URL}`;
}
 
// Middleware to ensure a valid token
async function ensureValidToken(req, res, next) {
    if (!req.session.token) {
        return res.redirect(getKeycloakLoginUrl());
    }
 
    try {
        const decoded = jwt.decode(req.session.token);
        const now = Math.floor(Date.now() / 1000);
 
        if (decoded.exp < now) {
            console.log('Token expired, refreshing...');
 
const refreshResponse = await axios.post(
                `${KEYCLOAK_BASE_URL}/realms/${REALM}/protocol/openid-connect/token`,
                new URLSearchParams({
                    client_id: CLIENT_ID,
                    client_secret: CLIENT_SECRET,
                    grant_type: 'refresh_token',
                    refresh_token: req.session.refresh_token
                }),
                { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
            );
 
            req.session.token = refreshResponse.data.access_token;
            req.session.refresh_token = refreshResponse.data.refresh_token;
            console.log('Token refreshed successfully');
        }
 
        next();
    } catch (error) {
        console.error('Refresh failed:', error.response?.data || error.message);
 
        req.session.destroy(() => {
            res.redirect(getKeycloakLoginUrl());
        });
    }
}
 
// 1️⃣ Entry point - Redirect to UI or Keycloak
app.get('/', (req, res) => {
    console.log("Entry",req.session.token);
    if(req.session.token){
	res.redirect(UI_URL);
    }else{
	res.redirect(getKeycloakLoginUrl());
}
    
});
 
// 2️⃣ Handle OAuth callback from Keycloak
app.get('/callback', async (req, res) => {
    const code = req.query.code;
    if (!code) return res.status(400).send('Authorization code is missing');
    console.log("Callback",req.session.token);
    try {
const tokenResponse = await axios.post(
            `${KEYCLOAK_BASE_URL}/realms/${REALM}/protocol/openid-connect/token`,
            new URLSearchParams({
                client_id: CLIENT_ID,
                client_secret: CLIENT_SECRET,
                grant_type: 'authorization_code',
                code,
                redirect_uri: CALLBACK_URL
            }),
            { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
        );
 
        req.session.token = tokenResponse.data.access_token;
        req.session.refresh_token = tokenResponse.data.refresh_token;
        console.log('User authenticated successfully');
        res.redirect(UI_URL);
    } catch (error) {
        console.error('Token exchange failed:', error.response?.data || error.message);
        res.status(500).send('Authentication failed');
    }
});
 
// 3️⃣ Forward all `/api/backend/*` requests dynamically
app.use('/api/backend', ensureValidToken, async (req, res) => {
    try {
        const backendPath = req.originalUrl.replace('/api/backend', ''); // Extract dynamic path
        const backendUrl = `${BACKEND_URL}${backendPath}`; // Construct full backend URL
 
        console.log(`Forwarding request to: ${backendUrl}`);
 
        const response = await axios({
            method: req.method,  // Use the same HTTP method
            url: backendUrl,
            headers: { Authorization: `Bearer ${req.session.token}` },
            data: req.body  // Pass request body if applicable
        });
 
        res.status(response.status).json(response.data);
    } catch (error) {
        console.error('API call failed:', error.response?.data || error.message);
        res.status(error.response?.status || 500).json({ error: 'Backend request failed' });
    }
});
 
app.listen(PORT, () => console.log(`API Gateway running at http://localhost:${PORT}`));