import { Component } from '@angular/core';

@Component({
  selector: 'app-flight',
  imports: [],
  templateUrl: './flight.component.html',
  styleUrl: './flight.component.scss'
})
export class FlightComponent {

}
