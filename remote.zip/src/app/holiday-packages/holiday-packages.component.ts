import { Component } from '@angular/core';

@Component({
  selector: 'app-holiday-packages',
  imports: [],
  templateUrl: './holiday-packages.component.html',
  styleUrl: './holiday-packages.component.scss'
})
export class HolidayPackagesComponent {

}
